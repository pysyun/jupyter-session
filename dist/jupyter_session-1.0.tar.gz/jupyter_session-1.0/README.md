# jupyter-session

## Installation
To install, run the following BASH command:
```shell
pip install git+https://github.com/ChoNakyun/jupyter-session.git --upgrade
```
